# About this copy

AstroPaper at commit 35cfa7fbe0b897306d27670d3819e55d5205f3dd, MIT, copyright 2023
Sat Naing, included here as the upstream that the Quire studio edition was adapted
from. Every source file is present. The upstream's demonstration screenshots and
preview bitmaps (png, jpg, gif, webp and ico) have been left out of this archive,
because the Quire edition uses no images at all and does not redistribute them.
Fetch the pinned commit from https://github.com/satnaing/astro-paper for those.

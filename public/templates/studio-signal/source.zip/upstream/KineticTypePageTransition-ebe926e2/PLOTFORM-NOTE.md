# Upstream copy

This is the unmodified Codrops Kinetic Type Page Transition at commit
ebe926e2f1de42950c36ff8a678321155280c1af, MIT, included so the foundation this
edition adapts travels with it. Only the git metadata was removed.

The Plotform edition built on top of it is the sibling `overtone/` folder. It
does not use this tree at run time, and it does not use GSAP, which the upstream
`package.json` lists and which carries its own licence rather than an MIT one.

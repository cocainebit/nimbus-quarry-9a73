---
title: Team Grid
spacing: all
blocks:
  _component: 'page-sections/people/team-grid'
  eyebrowText: 'Our team'
  heading: 'Meet the team'
  subtext: 'Get to know the people behind our work.'
  teamMembers:
    - name: 'Michael Chen'
      role: 'CEO & Founder'
      bio: 'Michael brings over 15 years of experience in product development and team leadership.'
      imageSource: /src/assets/images/staff-1.png
      imageAlt: 'Michael Chen'
    - name: 'Sarah Johnson'
      role: 'Lead Developer'
      bio: 'Sarah specializes in building scalable applications and mentoring engineering teams.'
      imageSource: /src/assets/images/staff-2-1.png
      imageAlt: 'Sarah Johnson'
    - name: 'David Kim'
      role: 'Design Director'
      bio: 'David creates beautiful, user-centered designs that solve real problems.'
      imageSource: /src/assets/images/staff-3-1.png
      imageAlt: 'David Kim'
    - name: 'Emily Rodriguez'
      role: 'Product Manager'
      bio: 'Emily ensures our products meet user needs while staying aligned with business goals.'
      imageSource: /src/assets/images/staff-4.png
      imageAlt: 'Emily Rodriguez'
    - name: 'Alex Thompson'
      role: 'Marketing Director'
      bio: 'Alex drives brand strategy and connects our products with the right audiences.'
      imageSource: /src/assets/images/staff-5.png
      imageAlt: 'Alex Thompson'
    - name: 'Jordan Martinez'
      role: 'UX Researcher'
      bio: 'Jordan uncovers user insights that shape our product decisions and improve experiences.'
      imageSource: /src/assets/images/staff-6.png
      imageAlt: 'Jordan Martinez'
---

---
title: Bottom right background image
spacing:
blocks:
  _component: 'page-sections/builders/custom-section'
  paddingVertical: 2xl
  paddingHorizontal: md
  colorScheme: dark
  background:
    type: image
    positionVertical: bottom
    positionHorizontal: right
    priority: false
    imageSource: /src/assets/images/about-hero.png
    imageAlt: 'Dunedin cliffside'
    overlay: -0.3
  contentSections:
    - _component: building-blocks/core-elements/heading
      alignmentHorizontal: end
      text: Build bold. Launch fast.
      level: h3
---

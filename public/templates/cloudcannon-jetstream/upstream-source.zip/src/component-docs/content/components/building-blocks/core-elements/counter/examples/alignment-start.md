---
title: 'Start Alignment'
spacing: 'all'
blocks:
  _component: 'building-blocks/core-elements/counter'
  number: 50000
  prefix:
  suffix: '+'
  alignmentHorizontal: start
---

---
title: 'End alignment with horizontal direction'
spacing: 'all'
blocks:
  - _component: 'building-blocks/core-elements/list'
    items:
      - text: First list item
        iconName: check-circle
      - text: Second list item
        iconName: check-circle
      - text: Third list item
        iconName: check-circle
    direction: horizontal
    alignmentHorizontal: end
    size: md
---

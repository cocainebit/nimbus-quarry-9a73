---
title: Testimonial
spacing: all
blocks:
  - _component: building-blocks/core-elements/testimonial
    text: If it doesn’t make you a little nervous, it’s probably not growth.
    authorName: Jules Mercer
    authorDescription: Travel photographer
    authorImage: /src/assets/images/staff-1.png
    alignmentHorizontal: start
---

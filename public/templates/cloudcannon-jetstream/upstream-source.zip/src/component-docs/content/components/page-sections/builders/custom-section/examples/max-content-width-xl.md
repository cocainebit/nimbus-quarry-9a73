---
title: xl max content width
spacing:
blocks:
  _component: 'page-sections/builders/custom-section'
  backgroundColor: 'surface'
  maxContentWidth: xl
  contentSections:
    - _component: building-blocks/core-elements/heading
      text: This Custom Section has xl max content width.
      level: h2
      alignmentHorizontal: center
      style: 'border: 1px solid var(--color-border)'
---

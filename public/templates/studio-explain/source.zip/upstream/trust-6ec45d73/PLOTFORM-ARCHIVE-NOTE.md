# What this copy of ncase/trust leaves out, and why

This is a trimmed copy of The Evolution of Trust by Nicky Case,
https://github.com/ncase/trust, pinned at commit
6ec45d73befdb922bd40654dd1c1c903a953562f. The project is dedicated to the
public domain under CC0 1.0 Universal; the dedication is in LICENSE.

It is archived here because the Plotform studio edition "Threshold" was
adapted from it. Threshold takes its chaptered reading, its chapter rail and
its one widget per step, and it uses two of its drawings. Neither its code nor
its artwork is loaded by Threshold at runtime; this copy is provenance.

Left out of this archive:

- **assets/sounds and every other audio file.** The upstream README lists the
  sound effects one by one and they are a mixture of licences. At least one is
  Creative Commons Attribution NonCommercial ("click plink pop boop bonk" by
  Owdeo) and one is Creative Commons Sampling Plus (the slot machine by
  lukaso), neither of which can be redistributed inside a website template.
  Threshold uses no audio at all.
- **css/FuturaHandwritten.ttf**, a third party font by Bill Snyder obtained
  from dafont. It is credited in the upstream README and is not covered by the
  CC0 dedication, so it is not redistributed here.
- **js/lib**, the vendored third party libraries: PIXI.js, Howler.js, Tween.js,
  Balloon.css, Q, MinPubSub and Pegasus. Each has its own licence and none of
  them is used by Threshold, which has no dependencies.
- **Most of assets**, which is Adobe Animate texture atlases for a canvas
  renderer. The one file Threshold actually cut artwork from,
  assets/splash/splash_peep.png, is kept here with its frame data so that the
  provenance recorded in Threshold's SOURCE.json can be checked.
- **peeps/peep and peeps/polygon**, the bitmap galleries on the credits page.

Everything kept here is Nicky Case's own work under the CC0 dedication.

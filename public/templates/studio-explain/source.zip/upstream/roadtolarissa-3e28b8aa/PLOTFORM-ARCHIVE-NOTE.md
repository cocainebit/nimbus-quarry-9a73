# What this copy of roadtolarissa leaves out, and why

This is a trimmed copy of roadtolarissa by Adam Pearce,
https://github.com/1wheel/roadtolarissa, pinned at commit
3e28b8aace38d09984a4714ea0c21669081f5dee, MIT, copyright 2012 to 2018 Adam
Pearce. The licence is in License.

It is archived here because the Plotform studio edition "Threshold" was adapted
from it: the newsprint ground and the 750 pixel measure from source/style.css,
the chart manners from the per post stylesheets, figures drawn as SVG from the
numbers, hand drawn annotation arrows, and the scroll driven chart state from
source/msi-4096/graph-scroll.js. None of its code is loaded by Threshold, which
has no dependencies; this copy is provenance.

Kept: the licence, the readme, the package manifest, the base stylesheet, the
shared helpers, and the two posts whose stylesheets and scripts the edition
actually studied.

Left out: the full post archive, source/images and source/javascripts, which
together are about ninety megabytes of datasets, screenshots and photographs
belonging to individual posts. None of it was used and none of it is imagery
this edition could redistribute.

Note on source/shared/swoopyarrows.js: that file is itself vendored by
roadtolarissa from bizweekgraphics under its own terms. Threshold did not copy
it. The annotation arrow in Threshold is written for that edition as a
quadratic curve with a head aimed along its tangent.

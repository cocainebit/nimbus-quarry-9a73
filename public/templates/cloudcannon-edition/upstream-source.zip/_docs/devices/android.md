---
title: Android
category: Devices
order: 2
---

Use ChatApp on all of your Android devices. Every version is supported.

To install ChatApp on your device:

1. Open the Google Play Store
2. Search for ChatApp
3. Select **Install**

![](/images/placeholders/field-800x600.svg)
